import mongoose from "mongoose";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import Hospital from "../src/models/hospital.model.mjs";
import PharmacyInventory from "../src/models/pharmacy-inventory.model.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(__dirname, "../.env") });

const medicines = [
  // Tablets
  { medicineName: "Paracetamol 500mg", genericName: "Acetaminophen", brand: "Crocin", category: "tablet", manufacturer: "GSK", quantity: 500, reorderLevel: 100, unitPrice: 2, mrp: 2.5 },
  { medicineName: "Amoxicillin 500mg", genericName: "Amoxicillin", brand: "Mox", category: "tablet", manufacturer: "Sun Pharma", quantity: 300, reorderLevel: 50, unitPrice: 5, mrp: 6 },
  { medicineName: "Ibuprofen 400mg", genericName: "Ibuprofen", brand: "Advil", category: "tablet", manufacturer: "Pfizer", quantity: 400, reorderLevel: 80, unitPrice: 3, mrp: 4 },
  { medicineName: "Cetirizine 10mg", genericName: "Cetirizine", brand: "Zyrtec", category: "tablet", manufacturer: "Cipla", quantity: 600, reorderLevel: 150, unitPrice: 1.5, mrp: 2 },
  { medicineName: "Metformin 500mg", genericName: "Metformin", brand: "Glycomet", category: "tablet", manufacturer: "USV", quantity: 1000, reorderLevel: 200, unitPrice: 1, mrp: 1.5 },
  { medicineName: "Amlodipine 5mg", genericName: "Amlodipine", brand: "Amlokind", category: "tablet", manufacturer: "Mankind", quantity: 800, reorderLevel: 100, unitPrice: 2.5, mrp: 3 },
  { medicineName: "Pantoprazole 40mg", genericName: "Pantoprazole", brand: "Pan 40", category: "tablet", manufacturer: "Alkem", quantity: 500, reorderLevel: 100, unitPrice: 4, mrp: 5 },
  { medicineName: "Atorvastatin 20mg", genericName: "Atorvastatin", brand: "Lipitor", category: "tablet", manufacturer: "Pfizer", quantity: 300, reorderLevel: 50, unitPrice: 8, mrp: 10 },
  { medicineName: "Levocetirizine 5mg", genericName: "Levocetirizine", brand: "Xyzal", category: "tablet", manufacturer: "Sanofi", quantity: 400, reorderLevel: 100, unitPrice: 2.5, mrp: 3.5 },
  { medicineName: "Azithromycin 500mg", genericName: "Azithromycin", brand: "Azee", category: "tablet", manufacturer: "Cipla", quantity: 200, reorderLevel: 50, unitPrice: 15, mrp: 20 },
  
  // Syrups
  { medicineName: "Cough Syrup D", genericName: "Dextromethorphan", brand: "Benadryl", category: "syrup", manufacturer: "J&J", quantity: 150, reorderLevel: 30, unitPrice: 80, mrp: 100 },
  { medicineName: "Paracetamol Syrup", genericName: "Acetaminophen", brand: "Calpol", category: "syrup", manufacturer: "GSK", quantity: 200, reorderLevel: 40, unitPrice: 40, mrp: 50 },
  { medicineName: "Ambroxol Syrup", genericName: "Ambroxol", brand: "Mucolite", category: "syrup", manufacturer: "Dr. Reddy's", quantity: 120, reorderLevel: 20, unitPrice: 60, mrp: 75 },
  { medicineName: "Lactulose Solution", genericName: "Lactulose", brand: "Duphalac", category: "syrup", manufacturer: "Abbott", quantity: 100, reorderLevel: 20, unitPrice: 150, mrp: 180 },
  { medicineName: "Multivitamin Syrup", genericName: "Vitamins", brand: "Zincovit", category: "syrup", manufacturer: "Apex", quantity: 250, reorderLevel: 50, unitPrice: 120, mrp: 140 },
  { medicineName: "Ibuprofen Suspension", genericName: "Ibuprofen", brand: "Ibugesic", category: "syrup", manufacturer: "Cipla", quantity: 180, reorderLevel: 30, unitPrice: 45, mrp: 55 },
  { medicineName: "Ondansetron Syrup", genericName: "Ondansetron", brand: "Ondem", category: "syrup", manufacturer: "Alkem", quantity: 90, reorderLevel: 15, unitPrice: 35, mrp: 45 },
  { medicineName: "Levosalbutamol Syrup", genericName: "Levosalbutamol", brand: "Asthalin", category: "syrup", manufacturer: "Cipla", quantity: 110, reorderLevel: 20, unitPrice: 50, mrp: 60 },
  { medicineName: "Calcium Suspension", genericName: "Calcium + D3", brand: "Calcimax", category: "syrup", manufacturer: "Meyer", quantity: 140, reorderLevel: 30, unitPrice: 90, mrp: 110 },
  { medicineName: "Iron Tonic", genericName: "Iron Folic Acid", brand: "Dexorange", category: "syrup", manufacturer: "Franco-Indian", quantity: 160, reorderLevel: 40, unitPrice: 130, mrp: 150 },

  // Injections
  { medicineName: "Diclofenac Injection", genericName: "Diclofenac", brand: "Voveran", category: "injection", manufacturer: "Novartis", quantity: 500, reorderLevel: 100, unitPrice: 10, mrp: 15 },
  { medicineName: "Ondansetron 2ml", genericName: "Ondansetron", brand: "Emset", category: "injection", manufacturer: "Cipla", quantity: 300, reorderLevel: 50, unitPrice: 12, mrp: 18 },
  { medicineName: "Pantoprazole IV", genericName: "Pantoprazole", brand: "Pantocid", category: "injection", manufacturer: "Sun Pharma", quantity: 400, reorderLevel: 80, unitPrice: 40, mrp: 55 },
  { medicineName: "Ceftriaxone 1g", genericName: "Ceftriaxone", brand: "Monocef", category: "injection", manufacturer: "Aristo", quantity: 600, reorderLevel: 120, unitPrice: 50, mrp: 70 },
  { medicineName: "Insulin Regular", genericName: "Insulin Human", brand: "Actrapid", category: "injection", manufacturer: "Novo Nordisk", quantity: 200, reorderLevel: 40, unitPrice: 150, mrp: 200 },
  { medicineName: "Adrenaline 1ml", genericName: "Epinephrine", brand: "Adrenor", category: "injection", manufacturer: "Samarth", quantity: 100, reorderLevel: 20, unitPrice: 15, mrp: 20 },
  { medicineName: "Hydrocortisone 100mg", genericName: "Hydrocortisone", brand: "Primacort", category: "injection", manufacturer: "Macleods", quantity: 150, reorderLevel: 30, unitPrice: 35, mrp: 50 },
  { medicineName: "Tramadol 2ml", genericName: "Tramadol", brand: "Supradol", category: "injection", manufacturer: "Intas", quantity: 250, reorderLevel: 50, unitPrice: 20, mrp: 30 },
  { medicineName: "B-Complex Injection", genericName: "Vitamin B", brand: "Neurobion", category: "injection", manufacturer: "P&G", quantity: 400, reorderLevel: 100, unitPrice: 8, mrp: 12 },
  { medicineName: "Tetanus Toxoid 0.5ml", genericName: "Tetanus Vaccine", brand: "Tetvac", category: "injection", manufacturer: "SII", quantity: 300, reorderLevel: 50, unitPrice: 25, mrp: 35 },

  // Capsules
  { medicineName: "Omeprazole 20mg", genericName: "Omeprazole", brand: "Omez", category: "capsule", manufacturer: "Dr. Reddy's", quantity: 500, reorderLevel: 100, unitPrice: 3, mrp: 4.5 },
  { medicineName: "Amoxicillin + Clavulanate", genericName: "Amoxyclav", brand: "Augmentin", category: "capsule", manufacturer: "GSK", quantity: 300, reorderLevel: 60, unitPrice: 20, mrp: 28 },
  { medicineName: "Vitamin E 400IU", genericName: "Vitamin E", brand: "Evion", category: "capsule", manufacturer: "P&G", quantity: 600, reorderLevel: 150, unitPrice: 2, mrp: 3 },
  { medicineName: "Doxycycline 100mg", genericName: "Doxycycline", brand: "Doxypal", category: "capsule", manufacturer: "Jagsonpal", quantity: 400, reorderLevel: 80, unitPrice: 4, mrp: 6 },
  { medicineName: "Pregabalin 75mg", genericName: "Pregabalin", brand: "Lyrica", category: "capsule", manufacturer: "Pfizer", quantity: 200, reorderLevel: 40, unitPrice: 15, mrp: 22 },
  { medicineName: "Rabeprazole + DSR", genericName: "Rabeprazole", brand: "Rablet D", category: "capsule", manufacturer: "Lupin", quantity: 450, reorderLevel: 90, unitPrice: 8, mrp: 12 },
  { medicineName: "Itraconazole 100mg", genericName: "Itraconazole", brand: "Canditral", category: "capsule", manufacturer: "Glenmark", quantity: 250, reorderLevel: 50, unitPrice: 18, mrp: 25 },
  
  // Ointments
  { medicineName: "Povidone Iodine", genericName: "Povidone Iodine", brand: "Betadine", category: "ointment", manufacturer: "Win-Medicare", quantity: 150, reorderLevel: 30, unitPrice: 80, mrp: 110 },
  { medicineName: "Diclofenac Gel", genericName: "Diclofenac", brand: "Volini", category: "ointment", manufacturer: "Sun Pharma", quantity: 200, reorderLevel: 40, unitPrice: 60, mrp: 85 },
  { medicineName: "Mupirocin Ointment", genericName: "Mupirocin", brand: "T-Bact", category: "ointment", manufacturer: "GSK", quantity: 120, reorderLevel: 25, unitPrice: 120, mrp: 150 },
  { medicineName: "Clotrimazole Cream", genericName: "Clotrimazole", brand: "Candid", category: "ointment", manufacturer: "Glenmark", quantity: 180, reorderLevel: 35, unitPrice: 70, mrp: 95 },
  { medicineName: "Silver Sulfadiazine", genericName: "Silver Sulfadiazine", brand: "Silverex", category: "ointment", manufacturer: "Sun Pharma", quantity: 100, reorderLevel: 20, unitPrice: 50, mrp: 75 },

  // Drops
  { medicineName: "Ciprofloxacin Eye Drops", genericName: "Ciprofloxacin", brand: "Ciplox", category: "drops", manufacturer: "Cipla", quantity: 150, reorderLevel: 30, unitPrice: 35, mrp: 50 },
  { medicineName: "Xylometazoline Nasal", genericName: "Xylometazoline", brand: "Otrivin", category: "drops", manufacturer: "GSK", quantity: 200, reorderLevel: 40, unitPrice: 55, mrp: 75 },
  { medicineName: "Saline Nasal Drops", genericName: "Sodium Chloride", brand: "Nasivion S", category: "drops", manufacturer: "P&G", quantity: 250, reorderLevel: 50, unitPrice: 40, mrp: 60 },
  { medicineName: "Carboxymethylcellulose", genericName: "Tears", brand: "Refresh Tears", category: "drops", manufacturer: "Allergan", quantity: 180, reorderLevel: 35, unitPrice: 130, mrp: 160 },
  { medicineName: "Timolol Eye Drops", genericName: "Timolol", brand: "Glucomol", category: "drops", manufacturer: "Allergan", quantity: 90, reorderLevel: 20, unitPrice: 90, mrp: 120 },

  // Other
  { medicineName: "ORS Sachet", genericName: "Oral Rehydration", brand: "Electral", category: "other", manufacturer: "FDC", quantity: 1000, reorderLevel: 200, unitPrice: 15, mrp: 20 },
  { medicineName: "Protein Powder", genericName: "Protein", brand: "Protinex", category: "other", manufacturer: "Danone", quantity: 50, reorderLevel: 10, unitPrice: 350, mrp: 400 },
  { medicineName: "Cotton Roll 500g", genericName: "Surgical Cotton", brand: "Local", category: "other", manufacturer: "Local", quantity: 80, reorderLevel: 20, unitPrice: 180, mrp: 220 }
];

const seedMedicines = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        console.log("Connected to MongoDB");

        const hospital = await Hospital.findOne();
        if (!hospital) {
            console.log("No hospital found");
            process.exit(1);
        }

        console.log("Seeding for hospital:", hospital.name);

        const expDate = new Date();
        expDate.setFullYear(expDate.getFullYear() + 2); // 2 years expiry

        for (let i = 0; i < medicines.length; i++) {
            const med = medicines[i];
            const batchNum = `BAT-${hospital._id.toString().substring(0,4).toUpperCase()}-${Math.floor(100000 + Math.random() * 900000)}`;
            
            await PharmacyInventory.updateOne(
                { hospitalId: hospital._id, medicineName: med.medicineName },
                { 
                    $set: {
                        ...med,
                        hospitalId: hospital._id,
                        batchNumber: batchNum,
                        expiryDate: expDate,
                        manufacturedDate: new Date()
                    }
                },
                { upsert: true }
            );
        }

        console.log(`Seeded 50 medicines successfully!`);
        process.exit(0);
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
};

seedMedicines();
