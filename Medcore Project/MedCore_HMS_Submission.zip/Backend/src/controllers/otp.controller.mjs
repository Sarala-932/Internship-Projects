import User from "../models/user.model.mjs";
import Otp from "../models/otp.model.mjs";
import {generateOtp, hashOtp, compareOtp, getOtpExpiry} from "../utils/otp.mjs";
import {sendOtpEmail} from "../utils/mailer.mjs";

const MAX_ATTEMPTS = 5;

export async function issueOtp(email, firstName, purpose = "signup") {
    const code = generateOtp();
    const codeHash = await hashOtp(code);

    await Otp.deleteMany({email, purpose, consumedAt: null});
    await Otp.create({
        email,
        codeHash,
        purpose,
        expiresAt: getOtpExpiry(),
    });

    const sendResult = await sendOtpEmail({to: email, name: firstName, otp: code});
    return { code, sendResult };
}

export async function verifyOtp(req, res) {
    try {
        const {email, code, purpose} = req.body || {};
        if (!email || !code) return res.status(400).json({message: "Email and code required"});
        if (String(code).length !== 6) return res.status(400).json({message: "Invalid code"});

        const otpPurpose = purpose || "signup";

        const otp = await Otp.findOne({
            email: String(email).toLowerCase(),
            purpose: otpPurpose,
            consumedAt: null,
        }).sort({createdAt: -1});

        if (!otp) return res.status(400).json({message: "No pending OTP"});
        if (otp.expiresAt < new Date()) return res.status(400).json({message: "OTP expired"});
        if (otp.attempts >= MAX_ATTEMPTS) return res.status(429).json({message: "Too many attempts"});

        const ok = await compareOtp(String(code), otp.codeHash);
        otp.attempts += 1;

        if (!ok) {
            await otp.save();
            return res.status(400).json({message: "Invalid code"});
        }

        otp.consumedAt = new Date();
        await otp.save();
        
        const user = await User.findOne({email});
        user.isEmailVerified = true;
        user.lastLoginAt = new Date();
        await user.save();
        
        const { issueTokenPair } = await import("../services/auth.service.mjs");
        const { accessCookieOpts, refreshCookieOpts } = await import("./token.controller.mjs");
        
        const { accessToken, refreshToken } = await issueTokenPair(user);
        
        // Set secure cookies
        res.cookie("accessToken", accessToken, accessCookieOpts);
        res.cookie("refreshToken", refreshToken, refreshCookieOpts);

        return res.json({
            message: "Email verified and logged in",
            accessToken,
            user: {
                id: user._id,
                email: user.email,
                firstName: user.firstName,
                lastName: user.lastName,
                role: user.role,
                hospitalId: user.hospitalId,
                isEmailVerified: user.isEmailVerified,
            }
        });
    } catch (err) {
        console.error("verifyOtp error:", err);
        return res.status(500).json({message: "Server error"});
    }
}

export async function resendOtp(req, res) {
    try {
        const {email, purpose} = req.body || {};
        if (!email) return res.status(400).json({message: "Email required"});

        const user = await User.findOne({email: String(email).toLowerCase()});
        if (user) {
            const otpResponse = await issueOtp(user.email, user.firstName, purpose);
            const responseObj = {message: "If the email exists, an OTP was sent."};
            if (otpResponse.sendResult && otpResponse.sendResult.success === false) {
                 responseObj.demoOtp = otpResponse.code;
            }
            return res.json(responseObj);
        }
        return res.json({message: "If the email exists, an OTP was sent."});
    } catch (err) {
        console.error("resendOtp error:", err);
        return res.status(500).json({message: "Server error"});
    }
}
