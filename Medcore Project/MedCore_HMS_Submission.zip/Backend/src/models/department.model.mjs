import mongoose from "mongoose";

const departmentSchema = new mongoose.Schema(
    {
        hospitalId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Hospital",
            required: true,
        },
        name: {
            type: String,
            required: true,
        },
        code: {
            type: String,
            required: true,
            uppercase: true,
            trim: true,
        },
        headDoctorId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
        },
        description: {
            type: String,
        },
        isActive: {
            type: Boolean,
            default: true,
        },
    },
    {timestamps: true},
);


departmentSchema.index({hospitalId: 1, code: 1}, {unique: true});
departmentSchema.index({hospitalId: 1, isActive: 1});

export default mongoose.model("Department", departmentSchema);
